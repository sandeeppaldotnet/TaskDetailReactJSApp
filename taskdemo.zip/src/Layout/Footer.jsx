const Footer = () => {
    return (
      <p
        style={{
          color: "gray",
          backgroundColor: "black",
          marginTop: "10px",
          textAlign: "center",
        }}
      >
       Learn and enjoy coding!
      </p>
    );
  };
  
  export default Footer;
  
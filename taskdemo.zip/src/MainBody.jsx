import React from "react";
import Student from "./Components/Student/Student";
import StudentReview from "./Components/Student/StudentReview";

const MainBody = () => {
  const whatWeWillLearn = "React JS";
  const totalClass = 6;
  return (

    <div style={{ minHeight: "70vh" }}>
        <div className="col-8 offset-2">
        <h4>
          We are learning {whatWeWillLearn} by making project.
          Task Detail! <br />
          Total Class - {totalClass}
        </h4>
        <ul>
          <li>Used Concept: Functional and Class Components</li>
        </ul>
       
        <div className="container row">Students</div>
        </div>
        <div className="col-8 offset-2">
        <Student
          experience={2}
          name="Krishan"
          headshot="https://api.lorem.space/image/face?w=150&h=153"
        >
          <StudentReview />
        </Student>
        <Student
          experience={5}
          name="Angad"
          headshot="https://api.lorem.space/image/face?w=150&h=151"
        >
          <StudentReview />
        </Student>
        <Student
          experience={7}
          name="Pranav"
          headshot="https://api.lorem.space/image/face?w=150&h=150"
        />
      </div>
      </div>
  );
};


export default MainBody;
